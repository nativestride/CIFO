# Fantasy League Optimization Dashboard and Educational Website

## Project Overview
This project integrates comprehensive performance analysis metrics with a Fantasy League optimization problem. The goal is to:

1. Create interactive dashboards for comparing algorithm performance
2. Build an educational website demonstrating how optimization algorithms work
3. Enable users to experiment with different parameters and constraints
4. Visualize algorithm performance metrics in real-time

## Current Status
- [x] Finalized dashboard mockups for all algorithms
- [x] Analyzed Fantasy League code and data
- [ ] Refactor and integrate algorithms for Fantasy League
- [ ] Implement metric collection for real problem
- [ ] Design and implement dashboards for real problem
- [ ] Build interactive educational website
- [ ] Enable user parameterization and live optimization
- [ ] Validate results with real data
- [ ] Deploy educational website permanently

## Fantasy League Problem Analysis
The Fantasy League problem involves:
- Creating teams with players from different positions (GK, DEF, MID, FWD)
- Meeting position requirements for each team
- Staying within budget constraints
- Minimizing the standard deviation of team skills

## Algorithm Implementations
The codebase includes implementations for:
- Hill Climbing (standard and random restart)
- Simulated Annealing
- Genetic Algorithm (with various selection, crossover, and mutation operators)
- Island Genetic Algorithm (with different migration topologies)

## Next Steps
1. Refactor algorithms to collect comprehensive metrics
2. Integrate with Dash-based dashboards
3. Build interactive educational website
4. Implement user parameter controls
5. Deploy for permanent access
