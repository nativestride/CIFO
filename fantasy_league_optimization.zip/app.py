"""
Main Dash application for the Fantasy League optimization dashboard.

This module provides a comprehensive dashboard for analyzing the performance of
different optimization algorithms on the Fantasy League problem.
"""

import os
import json
import glob
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from dash import Dash, html, dcc, callback, Input, Output, State
import dash_bootstrap_components as dbc

# Initialize the Dash app
app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

# Define the layout
app.layout = html.Div([
    dbc.Container([
        dbc.Row([
            dbc.Col([
                html.H1("Fantasy League Optimization Dashboard", className="text-center my-4"),
                html.P(
                    "Comprehensive performance analysis of optimization algorithms applied to the Fantasy League problem",
                    className="text-center lead mb-4"
                )
            ])
        ]),
        
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader("Dashboard Navigation"),
                    dbc.CardBody([
                        dbc.Tabs([
                            dbc.Tab(label="Global Comparison", tab_id="global-comparison"),
                            dbc.Tab(label="Hill Climbing", tab_id="hill-climbing"),
                            dbc.Tab(label="Simulated Annealing", tab_id="simulated-annealing"),
                            dbc.Tab(label="Genetic Algorithm", tab_id="genetic-algorithm"),
                            dbc.Tab(label="Island GA", tab_id="island-ga"),
                            dbc.Tab(label="Statistical Analysis", tab_id="statistical-analysis")
                        ], id="tabs", active_tab="global-comparison")
                    ])
                ], className="mb-4")
            ])
        ]),
        
        # Global Comparison Tab Content
        html.Div(id="global-comparison-content", children=[
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Algorithm Performance Comparison"),
                        dbc.CardBody([
                            dcc.Graph(id="global-fitness-comparison")
                        ])
                    ], className="mb-4")
                ], width=12)
            ]),
            
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Solution Quality Metrics"),
                        dbc.CardBody([
                            dcc.Graph(id="solution-quality-comparison")
                        ])
                    ])
                ], width=6),
                
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Computational Efficiency Metrics"),
                        dbc.CardBody([
                            dcc.Graph(id="computational-efficiency-comparison")
                        ])
                    ])
                ], width=6)
            ], className="mb-4"),
            
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Convergence Behavior Metrics"),
                        dbc.CardBody([
                            dcc.Graph(id="convergence-behavior-comparison")
                        ])
                    ])
                ], width=6),
                
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Robustness and Reliability Metrics"),
                        dbc.CardBody([
                            dcc.Graph(id="robustness-reliability-comparison")
                        ])
                    ])
                ], width=6)
            ])
        ], style={"display": "block"}),
        
        # Hill Climbing Tab Content
        html.Div(id="hill-climbing-content", style={"display": "none"}, children=[
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Hill Climbing Convergence"),
                        dbc.CardBody([
                            dcc.Graph(id="hc-convergence-plot")
                        ])
                    ], className="mb-4")
                ], width=12)
            ]),
            
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Plateau Detection"),
                        dbc.CardBody([
                            dcc.Graph(id="hc-plateau-plot")
                        ])
                    ])
                ], width=6),
                
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Improvement Rate"),
                        dbc.CardBody([
                            dcc.Graph(id="hc-improvement-rate-plot")
                        ])
                    ])
                ], width=6)
            ], className="mb-4"),
            
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Hill Climbing Variants Comparison"),
                        dbc.CardBody([
                            dcc.Graph(id="hc-variants-comparison")
                        ])
                    ])
                ], width=12)
            ])
        ]),
        
        # Simulated Annealing Tab Content
        html.Div(id="simulated-annealing-content", style={"display": "none"}, children=[
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Simulated Annealing Convergence"),
                        dbc.CardBody([
                            dcc.Graph(id="sa-convergence-plot")
                        ])
                    ], className="mb-4")
                ], width=12)
            ]),
            
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Temperature Schedule"),
                        dbc.CardBody([
                            dcc.Graph(id="sa-temperature-plot")
                        ])
                    ])
                ], width=6),
                
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Acceptance Rate"),
                        dbc.CardBody([
                            dcc.Graph(id="sa-acceptance-rate-plot")
                        ])
                    ])
                ], width=6)
            ], className="mb-4"),
            
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Uphill Moves Analysis"),
                        dbc.CardBody([
                            dcc.Graph(id="sa-uphill-moves-plot")
                        ])
                    ])
                ], width=6),
                
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Cooling Schedule Efficiency"),
                        dbc.CardBody([
                            dcc.Graph(id="sa-cooling-efficiency-plot")
                        ])
                    ])
                ], width=6)
            ])
        ]),
        
        # Genetic Algorithm Tab Content
        html.Div(id="genetic-algorithm-content", style={"display": "none"}, children=[
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Genetic Algorithm Convergence"),
                        dbc.CardBody([
                            dcc.Graph(id="ga-convergence-plot")
                        ])
                    ], className="mb-4")
                ], width=12)
            ]),
            
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Population Diversity"),
                        dbc.CardBody([
                            dcc.Graph(id="ga-diversity-plot")
                        ])
                    ])
                ], width=6),
                
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Selection Pressure"),
                        dbc.CardBody([
                            dcc.Graph(id="ga-selection-pressure-plot")
                        ])
                    ])
                ], width=6)
            ], className="mb-4"),
            
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Crossover Success Rate"),
                        dbc.CardBody([
                            dcc.Graph(id="ga-crossover-success-plot")
                        ])
                    ])
                ], width=6),
                
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Mutation Impact"),
                        dbc.CardBody([
                            dcc.Graph(id="ga-mutation-impact-plot")
                        ])
                    ])
                ], width=6)
            ], className="mb-4"),
            
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("GA Variants Comparison"),
                        dbc.CardBody([
                            dcc.Graph(id="ga-variants-comparison")
                        ])
                    ])
                ], width=12)
            ])
        ]),
        
        # Island GA Tab Content
        html.Div(id="island-ga-content", style={"display": "none"}, children=[
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Island GA Convergence"),
                        dbc.CardBody([
                            dcc.Graph(id="island-ga-convergence-plot")
                        ])
                    ], className="mb-4")
                ], width=12)
            ]),
            
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Island Diversity"),
                        dbc.CardBody([
                            dcc.Graph(id="island-diversity-plot")
                        ])
                    ])
                ], width=6),
                
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Inter-Island Diversity"),
                        dbc.CardBody([
                            dcc.Graph(id="inter-island-diversity-plot")
                        ])
                    ])
                ], width=6)
            ], className="mb-4"),
            
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Migration Impact"),
                        dbc.CardBody([
                            dcc.Graph(id="migration-impact-plot")
                        ])
                    ])
                ], width=6),
                
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Island Convergence Rates"),
                        dbc.CardBody([
                            dcc.Graph(id="island-convergence-rates-plot")
                        ])
                    ])
                ], width=6)
            ], className="mb-4"),
            
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Migration Topology Comparison"),
                        dbc.CardBody([
                            dcc.Graph(id="migration-topology-comparison")
                        ])
                    ])
                ], width=12)
            ])
        ]),
        
        # Statistical Analysis Tab Content
        html.Div(id="statistical-analysis-content", style={"display": "none"}, children=[
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Statistical Significance Tests"),
                        dbc.CardBody([
                            html.P("Select algorithms to compare:"),
                            dbc.Checklist(
                                id="stat-test-algorithms",
                                options=[
                                    {"label": "Hill Climbing", "value": "HillClimbing"},
                                    {"label": "Simulated Annealing", "value": "SimulatedAnnealing"},
                                    {"label": "Genetic Algorithm", "value": "GeneticAlgorithm"},
                                    {"label": "Island GA", "value": "IslandGA"}
                                ],
                                value=["HillClimbing", "SimulatedAnnealing", "GeneticAlgorithm", "IslandGA"],
                                inline=True
                            ),
                            html.P("Select metric to compare:"),
                            dbc.Select(
                                id="stat-test-metric",
                                options=[
                                    {"label": "Best Fitness", "value": "best_fitness"},
                                    {"label": "Convergence Rate", "value": "convergence_rate"},
                                    {"label": "Total Time", "value": "total_time"},
                                    {"label": "Solution Stability", "value": "solution_stability"}
                                ],
                                value="best_fitness"
                            ),
                            html.Div(id="stat-test-results", className="mt-3")
                        ])
                    ], className="mb-4")
                ], width=12)
            ]),
            
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Distribution Analysis"),
                        dbc.CardBody([
                            dcc.Graph(id="distribution-analysis-plot")
                        ])
                    ])
                ], width=12)
            ], className="mb-4"),
            
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader("Correlation Analysis"),
                        dbc.CardBody([
                            dcc.Graph(id="correlation-analysis-plot")
                        ])
                    ])
                ], width=12)
            ])
        ]),
        
        # Hidden div for storing the data
        html.Div(id="metrics-data", style={"display": "none"})
    ])
])

# Callback to load metrics data
@app.callback(
    Output("metrics-data", "children"),
    Input("tabs", "active_tab")
)
def load_metrics_data(active_tab):
    # Load all metrics files
    metrics_files = glob.glob("/home/ubuntu/fantasy_league_dashboard/metrics_data/*.json")
    
    if not metrics_files:
        # If no real data is available, use dummy data
        return generate_dummy_metrics_data()
    
    # Load and combine metrics data
    all_metrics = []
    for file in metrics_files:
        with open(file, 'r') as f:
            metrics = json.load(f)
            all_metrics.append(metrics)
    
    return json.dumps(all_metrics)

# Function to generate dummy metrics data for demonstration
def generate_dummy_metrics_data():
    algorithms = ["HillClimbing", "SimulatedAnnealing", "GeneticAlgorithm", "IslandGA"]
    all_metrics = []
    
    for algorithm in algorithms:
        # Generate basic metrics
        iterations = list(range(100))
        fitness_history = [20 - 15 * (1 - np.exp(-i / 30)) + np.random.normal(0, 1) for i in iterations]
        time_history = [0.01 * i + np.random.normal(0, 0.005) for i in iterations]
        
        metrics = {
            "algorithm": algorithm,
            "timestamp": "2025-05-27T00:00:00",
            "iterations": iterations,
            "fitness_history": fitness_history,
            "time_history": time_history,
            "solution_quality": {
                "best_fitness": min(fitness_history),
                "final_fitness": fitness_history[-1],
                "fitness_improvement": fitness_history[0] - fitness_history[-1]
            },
            "computational_efficiency": {
                "total_time": sum(time_history),
                "average_time_per_iteration": sum(time_history) / len(time_history),
                "total_iterations": len(iterations)
            },
            "convergence_behavior": {
                "iterations_to_best": fitness_history.index(min(fitness_history)),
                "convergence_rate": (fitness_history[0] - fitness_history[-1]) / len(fitness_history),
                "stagnation_events": sum(1 for i in range(1, len(fitness_history))
                                      if abs(fitness_history[i] - fitness_history[i-1]) < 0.01)
            },
            "robustness_reliability": {
                "fitness_variance": np.var(fitness_history),
                "solution_stability": 1.0 - (np.std(fitness_history[-10:]) / 
                                          np.mean(fitness_history[-10:])
                                          if len(fitness_history) >= 10 else 0)
            },
            "algorithm_specific": {}
        }
        
        # Add algorithm-specific metrics
        if algorithm == "HillClimbing":
            metrics["algorithm_specific"] = {
                "plateau_events": [i for i in range(1, len(fitness_history)) 
                                 if abs(fitness_history[i] - fitness_history[i-1]) < 0.01],
                "local_optima_escapes": [10, 25, 40, 60],
                "neighborhood_sizes": [11] * len(iterations),
                "improvement_rates": [fitness_history[i-1] - fitness_history[i] if i > 0 else 0 
                                    for i in range(len(fitness_history))]
            }
        elif algorithm == "SimulatedAnnealing":
            temperature_history = [100 * (0.95 ** i) for i in range(len(iterations))]
            metrics["algorithm_specific"] = {
                "temperature_history": temperature_history,
                "acceptance_rates": [0.9 * (1 - i/len(iterations)) + 0.1 * np.random.random() 
                                   for i in range(len(iterations))],
                "acceptance_probabilities": [min(1.0, np.exp(-0.1 / t)) if t > 0 else 0 
                                          for t in temperature_history],
                "uphill_moves_accepted": [1 if np.random.random() < 0.3 * (1 - i/len(iterations)) else 0 
                                        for i in range(len(iterations))],
                "cooling_schedule_efficiency": [0.95] * len(iterations)
            }
        elif algorithm == "GeneticAlgorithm":
            metrics["algorithm_specific"] = {
                "population_diversity": [0.8 * np.exp(-i / 50) + 0.2 * np.random.random() 
                                       for i in range(len(iterations))],
                "selection_pressure": [1.2 + 0.3 * np.random.random() for i in range(len(iterations))],
                "crossover_success_rates": [0.6 + 0.2 * np.random.random() for i in range(len(iterations))],
                "mutation_impact": [0.1 * np.random.random() for i in range(len(iterations))],
                "generation_improvement_rates": [fitness_history[i-1] - fitness_history[i] if i > 0 else 0 
                                              for i in range(len(fitness_history))]
            }
        elif algorithm == "IslandGA":
            metrics["algorithm_specific"] = {
                "island_diversity": [0.7 * np.exp(-i / 70) + 0.3 * np.random.random() 
                                   for i in range(len(iterations))],
                "inter_island_diversity": [0.6 * np.exp(-i / 60) + 0.4 * np.random.random() 
                                         for i in range(len(iterations))],
                "migration_events": [i for i in range(len(iterations)) if i % 10 == 0 and i > 0],
                "migration_impact": [0.5 * np.random.random() for i in range(len(iterations) // 10)],
                "island_convergence_rates": [0.1 * np.random.random() for i in range(len(iterations))]
            }
        
        all_metrics.append(metrics)
    
    return json.dumps(all_metrics)

# Callback to update tab content visibility
@app.callback(
    [Output("global-comparison-content", "style"),
     Output("hill-climbing-content", "style"),
     Output("simulated-annealing-content", "style"),
     Output("genetic-algorithm-content", "style"),
     Output("island-ga-content", "style"),
     Output("statistical-analysis-content", "style")],
    Input("tabs", "active_tab")
)
def update_tab_content(active_tab):
    tab_styles = [{"display": "none"}] * 6
    
    if active_tab == "global-comparison":
        tab_styles[0] = {"display": "block"}
    elif active_tab == "hill-climbing":
        tab_styles[1] = {"display": "block"}
    elif active_tab == "simulated-annealing":
        tab_styles[2] = {"display": "block"}
    elif active_tab == "genetic-algorithm":
        tab_styles[3] = {"display": "block"}
    elif active_tab == "island-ga":
        tab_styles[4] = {"display": "block"}
    elif active_tab == "statistical-analysis":
        tab_styles[5] = {"display": "block"}
    
    return tab_styles

# Callback for global fitness comparison plot
@app.callback(
    Output("global-fitness-comparison", "figure"),
    Input("metrics-data", "children")
)
def update_global_fitness_comparison(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    fig = go.Figure()
    
    for metrics in metrics_list:
        algorithm = metrics["algorithm"]
        iterations = metrics["iterations"]
        fitness_history = metrics["fitness_history"]
        
        fig.add_trace(go.Scatter(
            x=iterations,
            y=fitness_history,
            mode="lines",
            name=algorithm
        ))
    
    fig.update_layout(
        title="Fitness Convergence Comparison",
        xaxis_title="Iterations",
        yaxis_title="Fitness (lower is better)",
        legend_title="Algorithm",
        template="plotly_white"
    )
    
    return fig

# Callback for solution quality comparison plot
@app.callback(
    Output("solution-quality-comparison", "figure"),
    Input("metrics-data", "children")
)
def update_solution_quality_comparison(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    algorithms = []
    best_fitness = []
    final_fitness = []
    fitness_improvement = []
    
    for metrics in metrics_list:
        algorithms.append(metrics["algorithm"])
        best_fitness.append(metrics["solution_quality"]["best_fitness"])
        final_fitness.append(metrics["solution_quality"]["final_fitness"])
        fitness_improvement.append(metrics["solution_quality"]["fitness_improvement"])
    
    fig = make_subplots(rows=1, cols=3, subplot_titles=("Best Fitness", "Final Fitness", "Fitness Improvement"))
    
    fig.add_trace(go.Bar(x=algorithms, y=best_fitness, name="Best Fitness"), row=1, col=1)
    fig.add_trace(go.Bar(x=algorithms, y=final_fitness, name="Final Fitness"), row=1, col=2)
    fig.add_trace(go.Bar(x=algorithms, y=fitness_improvement, name="Fitness Improvement"), row=1, col=3)
    
    fig.update_layout(
        title="Solution Quality Metrics",
        showlegend=False,
        template="plotly_white"
    )
    
    return fig

# Callback for computational efficiency comparison plot
@app.callback(
    Output("computational-efficiency-comparison", "figure"),
    Input("metrics-data", "children")
)
def update_computational_efficiency_comparison(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    algorithms = []
    total_time = []
    avg_time_per_iteration = []
    total_iterations = []
    
    for metrics in metrics_list:
        algorithms.append(metrics["algorithm"])
        total_time.append(metrics["computational_efficiency"]["total_time"])
        avg_time_per_iteration.append(metrics["computational_efficiency"]["average_time_per_iteration"])
        total_iterations.append(metrics["computational_efficiency"]["total_iterations"])
    
    fig = make_subplots(rows=1, cols=3, subplot_titles=("Total Time", "Avg Time per Iteration", "Total Iterations"))
    
    fig.add_trace(go.Bar(x=algorithms, y=total_time, name="Total Time"), row=1, col=1)
    fig.add_trace(go.Bar(x=algorithms, y=avg_time_per_iteration, name="Avg Time per Iteration"), row=1, col=2)
    fig.add_trace(go.Bar(x=algorithms, y=total_iterations, name="Total Iterations"), row=1, col=3)
    
    fig.update_layout(
        title="Computational Efficiency Metrics",
        showlegend=False,
        template="plotly_white"
    )
    
    return fig

# Callback for convergence behavior comparison plot
@app.callback(
    Output("convergence-behavior-comparison", "figure"),
    Input("metrics-data", "children")
)
def update_convergence_behavior_comparison(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    algorithms = []
    iterations_to_best = []
    convergence_rate = []
    stagnation_events = []
    
    for metrics in metrics_list:
        algorithms.append(metrics["algorithm"])
        iterations_to_best.append(metrics["convergence_behavior"]["iterations_to_best"])
        convergence_rate.append(metrics["convergence_behavior"]["convergence_rate"])
        stagnation_events.append(metrics["convergence_behavior"]["stagnation_events"])
    
    fig = make_subplots(rows=1, cols=3, subplot_titles=("Iterations to Best", "Convergence Rate", "Stagnation Events"))
    
    fig.add_trace(go.Bar(x=algorithms, y=iterations_to_best, name="Iterations to Best"), row=1, col=1)
    fig.add_trace(go.Bar(x=algorithms, y=convergence_rate, name="Convergence Rate"), row=1, col=2)
    fig.add_trace(go.Bar(x=algorithms, y=stagnation_events, name="Stagnation Events"), row=1, col=3)
    
    fig.update_layout(
        title="Convergence Behavior Metrics",
        showlegend=False,
        template="plotly_white"
    )
    
    return fig

# Callback for robustness and reliability comparison plot
@app.callback(
    Output("robustness-reliability-comparison", "figure"),
    Input("metrics-data", "children")
)
def update_robustness_reliability_comparison(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    algorithms = []
    fitness_variance = []
    solution_stability = []
    
    for metrics in metrics_list:
        algorithms.append(metrics["algorithm"])
        fitness_variance.append(metrics["robustness_reliability"]["fitness_variance"])
        solution_stability.append(metrics["robustness_reliability"]["solution_stability"])
    
    fig = make_subplots(rows=1, cols=2, subplot_titles=("Fitness Variance", "Solution Stability"))
    
    fig.add_trace(go.Bar(x=algorithms, y=fitness_variance, name="Fitness Variance"), row=1, col=1)
    fig.add_trace(go.Bar(x=algorithms, y=solution_stability, name="Solution Stability"), row=1, col=2)
    
    fig.update_layout(
        title="Robustness and Reliability Metrics",
        showlegend=False,
        template="plotly_white"
    )
    
    return fig

# Callback for Hill Climbing convergence plot
@app.callback(
    Output("hc-convergence-plot", "figure"),
    Input("metrics-data", "children")
)
def update_hc_convergence_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Hill Climbing metrics
    hc_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "HillClimbing":
            hc_metrics = metrics
            break
    
    if not hc_metrics:
        return go.Figure()
    
    iterations = hc_metrics["iterations"]
    fitness_history = hc_metrics["fitness_history"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=fitness_history,
        mode="lines",
        name="Fitness"
    ))
    
    # Add plateau events
    if "plateau_events" in hc_metrics["algorithm_specific"]:
        plateau_events = hc_metrics["algorithm_specific"]["plateau_events"]
        plateau_y = [fitness_history[i] for i in plateau_events if i < len(fitness_history)]
        
        fig.add_trace(go.Scatter(
            x=plateau_events,
            y=plateau_y,
            mode="markers",
            marker=dict(size=10, color="red"),
            name="Plateau Events"
        ))
    
    fig.update_layout(
        title="Hill Climbing Convergence",
        xaxis_title="Iterations",
        yaxis_title="Fitness (lower is better)",
        template="plotly_white"
    )
    
    return fig

# Callback for Hill Climbing plateau plot
@app.callback(
    Output("hc-plateau-plot", "figure"),
    Input("metrics-data", "children")
)
def update_hc_plateau_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Hill Climbing metrics
    hc_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "HillClimbing":
            hc_metrics = metrics
            break
    
    if not hc_metrics or "plateau_events" not in hc_metrics["algorithm_specific"]:
        return go.Figure()
    
    iterations = hc_metrics["iterations"]
    plateau_events = hc_metrics["algorithm_specific"]["plateau_events"]
    
    # Create histogram of plateau events
    fig = go.Figure()
    
    fig.add_trace(go.Histogram(
        x=plateau_events,
        nbinsx=10,
        name="Plateau Events"
    ))
    
    fig.update_layout(
        title="Plateau Events Distribution",
        xaxis_title="Iteration",
        yaxis_title="Count",
        template="plotly_white"
    )
    
    return fig

# Callback for Hill Climbing improvement rate plot
@app.callback(
    Output("hc-improvement-rate-plot", "figure"),
    Input("metrics-data", "children")
)
def update_hc_improvement_rate_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Hill Climbing metrics
    hc_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "HillClimbing":
            hc_metrics = metrics
            break
    
    if not hc_metrics or "improvement_rates" not in hc_metrics["algorithm_specific"]:
        return go.Figure()
    
    iterations = hc_metrics["iterations"]
    improvement_rates = hc_metrics["algorithm_specific"]["improvement_rates"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=improvement_rates,
        mode="lines",
        name="Improvement Rate"
    ))
    
    fig.update_layout(
        title="Hill Climbing Improvement Rate",
        xaxis_title="Iterations",
        yaxis_title="Improvement Rate",
        template="plotly_white"
    )
    
    return fig

# Callback for Hill Climbing variants comparison
@app.callback(
    Output("hc-variants-comparison", "figure"),
    Input("metrics-data", "children")
)
def update_hc_variants_comparison(metrics_json):
    # For this demo, we'll create a dummy comparison of Hill Climbing variants
    variants = ["Standard", "Random Restart", "Intensive Search"]
    best_fitness = [5.2, 4.8, 4.5]
    iterations_to_best = [45, 60, 75]
    
    fig = make_subplots(rows=1, cols=2, subplot_titles=("Best Fitness", "Iterations to Best"))
    
    fig.add_trace(go.Bar(x=variants, y=best_fitness, name="Best Fitness"), row=1, col=1)
    fig.add_trace(go.Bar(x=variants, y=iterations_to_best, name="Iterations to Best"), row=1, col=2)
    
    fig.update_layout(
        title="Hill Climbing Variants Comparison",
        showlegend=False,
        template="plotly_white"
    )
    
    return fig

# Callback for Simulated Annealing convergence plot
@app.callback(
    Output("sa-convergence-plot", "figure"),
    Input("metrics-data", "children")
)
def update_sa_convergence_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Simulated Annealing metrics
    sa_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "SimulatedAnnealing":
            sa_metrics = metrics
            break
    
    if not sa_metrics:
        return go.Figure()
    
    iterations = sa_metrics["iterations"]
    fitness_history = sa_metrics["fitness_history"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=fitness_history,
        mode="lines",
        name="Fitness"
    ))
    
    fig.update_layout(
        title="Simulated Annealing Convergence",
        xaxis_title="Iterations",
        yaxis_title="Fitness (lower is better)",
        template="plotly_white"
    )
    
    return fig

# Callback for Simulated Annealing temperature plot
@app.callback(
    Output("sa-temperature-plot", "figure"),
    Input("metrics-data", "children")
)
def update_sa_temperature_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Simulated Annealing metrics
    sa_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "SimulatedAnnealing":
            sa_metrics = metrics
            break
    
    if not sa_metrics or "temperature_history" not in sa_metrics["algorithm_specific"]:
        return go.Figure()
    
    iterations = sa_metrics["iterations"]
    temperature_history = sa_metrics["algorithm_specific"]["temperature_history"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=temperature_history,
        mode="lines",
        name="Temperature"
    ))
    
    fig.update_layout(
        title="Temperature Schedule",
        xaxis_title="Iterations",
        yaxis_title="Temperature",
        template="plotly_white"
    )
    
    return fig

# Callback for Simulated Annealing acceptance rate plot
@app.callback(
    Output("sa-acceptance-rate-plot", "figure"),
    Input("metrics-data", "children")
)
def update_sa_acceptance_rate_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Simulated Annealing metrics
    sa_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "SimulatedAnnealing":
            sa_metrics = metrics
            break
    
    if not sa_metrics or "acceptance_rates" not in sa_metrics["algorithm_specific"]:
        return go.Figure()
    
    iterations = sa_metrics["iterations"]
    acceptance_rates = sa_metrics["algorithm_specific"]["acceptance_rates"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=acceptance_rates,
        mode="lines",
        name="Acceptance Rate"
    ))
    
    fig.update_layout(
        title="Acceptance Rate",
        xaxis_title="Iterations",
        yaxis_title="Acceptance Rate",
        template="plotly_white"
    )
    
    return fig

# Callback for Simulated Annealing uphill moves plot
@app.callback(
    Output("sa-uphill-moves-plot", "figure"),
    Input("metrics-data", "children")
)
def update_sa_uphill_moves_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Simulated Annealing metrics
    sa_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "SimulatedAnnealing":
            sa_metrics = metrics
            break
    
    if not sa_metrics or "uphill_moves_accepted" not in sa_metrics["algorithm_specific"]:
        return go.Figure()
    
    iterations = sa_metrics["iterations"]
    uphill_moves = sa_metrics["algorithm_specific"]["uphill_moves_accepted"]
    
    # Calculate cumulative uphill moves
    cumulative_uphill_moves = [sum(uphill_moves[:i+1]) for i in range(len(uphill_moves))]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=cumulative_uphill_moves,
        mode="lines",
        name="Cumulative Uphill Moves"
    ))
    
    fig.update_layout(
        title="Uphill Moves Analysis",
        xaxis_title="Iterations",
        yaxis_title="Cumulative Uphill Moves Accepted",
        template="plotly_white"
    )
    
    return fig

# Callback for Simulated Annealing cooling efficiency plot
@app.callback(
    Output("sa-cooling-efficiency-plot", "figure"),
    Input("metrics-data", "children")
)
def update_sa_cooling_efficiency_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Simulated Annealing metrics
    sa_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "SimulatedAnnealing":
            sa_metrics = metrics
            break
    
    if not sa_metrics or "cooling_schedule_efficiency" not in sa_metrics["algorithm_specific"]:
        return go.Figure()
    
    iterations = sa_metrics["iterations"]
    cooling_efficiency = sa_metrics["algorithm_specific"]["cooling_schedule_efficiency"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=cooling_efficiency,
        mode="lines",
        name="Cooling Efficiency"
    ))
    
    fig.update_layout(
        title="Cooling Schedule Efficiency",
        xaxis_title="Iterations",
        yaxis_title="Cooling Ratio",
        template="plotly_white"
    )
    
    return fig

# Callback for Genetic Algorithm convergence plot
@app.callback(
    Output("ga-convergence-plot", "figure"),
    Input("metrics-data", "children")
)
def update_ga_convergence_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Genetic Algorithm metrics
    ga_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "GeneticAlgorithm":
            ga_metrics = metrics
            break
    
    if not ga_metrics:
        return go.Figure()
    
    iterations = ga_metrics["iterations"]
    fitness_history = ga_metrics["fitness_history"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=fitness_history,
        mode="lines",
        name="Fitness"
    ))
    
    fig.update_layout(
        title="Genetic Algorithm Convergence",
        xaxis_title="Generations",
        yaxis_title="Fitness (lower is better)",
        template="plotly_white"
    )
    
    return fig

# Callback for Genetic Algorithm diversity plot
@app.callback(
    Output("ga-diversity-plot", "figure"),
    Input("metrics-data", "children")
)
def update_ga_diversity_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Genetic Algorithm metrics
    ga_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "GeneticAlgorithm":
            ga_metrics = metrics
            break
    
    if not ga_metrics or "population_diversity" not in ga_metrics["algorithm_specific"]:
        return go.Figure()
    
    iterations = ga_metrics["iterations"]
    diversity = ga_metrics["algorithm_specific"]["population_diversity"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=diversity,
        mode="lines",
        name="Population Diversity"
    ))
    
    fig.update_layout(
        title="Population Diversity",
        xaxis_title="Generations",
        yaxis_title="Diversity",
        template="plotly_white"
    )
    
    return fig

# Callback for Genetic Algorithm selection pressure plot
@app.callback(
    Output("ga-selection-pressure-plot", "figure"),
    Input("metrics-data", "children")
)
def update_ga_selection_pressure_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Genetic Algorithm metrics
    ga_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "GeneticAlgorithm":
            ga_metrics = metrics
            break
    
    if not ga_metrics or "selection_pressure" not in ga_metrics["algorithm_specific"]:
        return go.Figure()
    
    iterations = ga_metrics["iterations"]
    selection_pressure = ga_metrics["algorithm_specific"]["selection_pressure"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=selection_pressure,
        mode="lines",
        name="Selection Pressure"
    ))
    
    fig.update_layout(
        title="Selection Pressure",
        xaxis_title="Generations",
        yaxis_title="Selection Pressure",
        template="plotly_white"
    )
    
    return fig

# Callback for Genetic Algorithm crossover success plot
@app.callback(
    Output("ga-crossover-success-plot", "figure"),
    Input("metrics-data", "children")
)
def update_ga_crossover_success_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Genetic Algorithm metrics
    ga_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "GeneticAlgorithm":
            ga_metrics = metrics
            break
    
    if not ga_metrics or "crossover_success_rates" not in ga_metrics["algorithm_specific"]:
        return go.Figure()
    
    iterations = ga_metrics["iterations"]
    crossover_success = ga_metrics["algorithm_specific"]["crossover_success_rates"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=crossover_success,
        mode="lines",
        name="Crossover Success Rate"
    ))
    
    fig.update_layout(
        title="Crossover Success Rate",
        xaxis_title="Generations",
        yaxis_title="Success Rate",
        template="plotly_white"
    )
    
    return fig

# Callback for Genetic Algorithm mutation impact plot
@app.callback(
    Output("ga-mutation-impact-plot", "figure"),
    Input("metrics-data", "children")
)
def update_ga_mutation_impact_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Genetic Algorithm metrics
    ga_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "GeneticAlgorithm":
            ga_metrics = metrics
            break
    
    if not ga_metrics or "mutation_impact" not in ga_metrics["algorithm_specific"]:
        return go.Figure()
    
    iterations = ga_metrics["iterations"]
    mutation_impact = ga_metrics["algorithm_specific"]["mutation_impact"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=mutation_impact,
        mode="lines",
        name="Mutation Impact"
    ))
    
    fig.update_layout(
        title="Mutation Impact",
        xaxis_title="Generations",
        yaxis_title="Impact",
        template="plotly_white"
    )
    
    return fig

# Callback for Genetic Algorithm variants comparison
@app.callback(
    Output("ga-variants-comparison", "figure"),
    Input("metrics-data", "children")
)
def update_ga_variants_comparison(metrics_json):
    # For this demo, we'll create a dummy comparison of GA variants
    variants = ["Tournament + OnePoint", "Ranking + Uniform", "Tournament + TwoPoint", "Hybrid"]
    best_fitness = [4.8, 5.1, 4.6, 4.2]
    generations_to_best = [65, 55, 70, 45]
    
    fig = make_subplots(rows=1, cols=2, subplot_titles=("Best Fitness", "Generations to Best"))
    
    fig.add_trace(go.Bar(x=variants, y=best_fitness, name="Best Fitness"), row=1, col=1)
    fig.add_trace(go.Bar(x=variants, y=generations_to_best, name="Generations to Best"), row=1, col=2)
    
    fig.update_layout(
        title="Genetic Algorithm Variants Comparison",
        showlegend=False,
        template="plotly_white"
    )
    
    return fig

# Callback for Island GA convergence plot
@app.callback(
    Output("island-ga-convergence-plot", "figure"),
    Input("metrics-data", "children")
)
def update_island_ga_convergence_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Island GA metrics
    island_ga_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "IslandGA":
            island_ga_metrics = metrics
            break
    
    if not island_ga_metrics:
        return go.Figure()
    
    iterations = island_ga_metrics["iterations"]
    fitness_history = island_ga_metrics["fitness_history"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=fitness_history,
        mode="lines",
        name="Fitness"
    ))
    
    # Add migration events
    if "migration_events" in island_ga_metrics["algorithm_specific"]:
        migration_events = island_ga_metrics["algorithm_specific"]["migration_events"]
        migration_y = [fitness_history[i] for i in migration_events if i < len(fitness_history)]
        
        fig.add_trace(go.Scatter(
            x=migration_events,
            y=migration_y,
            mode="markers",
            marker=dict(size=10, color="red"),
            name="Migration Events"
        ))
    
    fig.update_layout(
        title="Island Genetic Algorithm Convergence",
        xaxis_title="Generations",
        yaxis_title="Fitness (lower is better)",
        template="plotly_white"
    )
    
    return fig

# Callback for Island diversity plot
@app.callback(
    Output("island-diversity-plot", "figure"),
    Input("metrics-data", "children")
)
def update_island_diversity_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Island GA metrics
    island_ga_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "IslandGA":
            island_ga_metrics = metrics
            break
    
    if not island_ga_metrics or "island_diversity" not in island_ga_metrics["algorithm_specific"]:
        return go.Figure()
    
    iterations = island_ga_metrics["iterations"]
    island_diversity = island_ga_metrics["algorithm_specific"]["island_diversity"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=island_diversity,
        mode="lines",
        name="Island Diversity"
    ))
    
    fig.update_layout(
        title="Island Diversity",
        xaxis_title="Generations",
        yaxis_title="Diversity",
        template="plotly_white"
    )
    
    return fig

# Callback for Inter-island diversity plot
@app.callback(
    Output("inter-island-diversity-plot", "figure"),
    Input("metrics-data", "children")
)
def update_inter_island_diversity_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Island GA metrics
    island_ga_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "IslandGA":
            island_ga_metrics = metrics
            break
    
    if not island_ga_metrics or "inter_island_diversity" not in island_ga_metrics["algorithm_specific"]:
        return go.Figure()
    
    iterations = island_ga_metrics["iterations"]
    inter_island_diversity = island_ga_metrics["algorithm_specific"]["inter_island_diversity"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=inter_island_diversity,
        mode="lines",
        name="Inter-Island Diversity"
    ))
    
    fig.update_layout(
        title="Inter-Island Diversity",
        xaxis_title="Generations",
        yaxis_title="Diversity",
        template="plotly_white"
    )
    
    return fig

# Callback for Migration impact plot
@app.callback(
    Output("migration-impact-plot", "figure"),
    Input("metrics-data", "children")
)
def update_migration_impact_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Island GA metrics
    island_ga_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "IslandGA":
            island_ga_metrics = metrics
            break
    
    if not island_ga_metrics or "migration_impact" not in island_ga_metrics["algorithm_specific"]:
        return go.Figure()
    
    migration_impact = island_ga_metrics["algorithm_specific"]["migration_impact"]
    migration_events = island_ga_metrics["algorithm_specific"]["migration_events"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        x=[f"Migration {i+1}" for i in range(len(migration_impact))],
        y=migration_impact,
        name="Migration Impact"
    ))
    
    fig.update_layout(
        title="Migration Impact",
        xaxis_title="Migration Event",
        yaxis_title="Impact (Fitness Improvement)",
        template="plotly_white"
    )
    
    return fig

# Callback for Island convergence rates plot
@app.callback(
    Output("island-convergence-rates-plot", "figure"),
    Input("metrics-data", "children")
)
def update_island_convergence_rates_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Find Island GA metrics
    island_ga_metrics = None
    for metrics in metrics_list:
        if metrics["algorithm"] == "IslandGA":
            island_ga_metrics = metrics
            break
    
    if not island_ga_metrics or "island_convergence_rates" not in island_ga_metrics["algorithm_specific"]:
        return go.Figure()
    
    iterations = island_ga_metrics["iterations"]
    island_convergence_rates = island_ga_metrics["algorithm_specific"]["island_convergence_rates"]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=iterations,
        y=island_convergence_rates,
        mode="lines",
        name="Island Convergence Rates"
    ))
    
    fig.update_layout(
        title="Island Convergence Rates",
        xaxis_title="Generations",
        yaxis_title="Convergence Rate",
        template="plotly_white"
    )
    
    return fig

# Callback for Migration topology comparison
@app.callback(
    Output("migration-topology-comparison", "figure"),
    Input("metrics-data", "children")
)
def update_migration_topology_comparison(metrics_json):
    # For this demo, we'll create a dummy comparison of migration topologies
    topologies = ["Ring", "Random Pair", "Broadcast Best"]
    best_fitness = [4.5, 4.7, 4.3]
    generations_to_best = [55, 60, 50]
    diversity_maintenance = [0.65, 0.55, 0.45]
    
    fig = make_subplots(rows=1, cols=3, subplot_titles=("Best Fitness", "Generations to Best", "Diversity Maintenance"))
    
    fig.add_trace(go.Bar(x=topologies, y=best_fitness, name="Best Fitness"), row=1, col=1)
    fig.add_trace(go.Bar(x=topologies, y=generations_to_best, name="Generations to Best"), row=1, col=2)
    fig.add_trace(go.Bar(x=topologies, y=diversity_maintenance, name="Diversity Maintenance"), row=1, col=3)
    
    fig.update_layout(
        title="Migration Topology Comparison",
        showlegend=False,
        template="plotly_white"
    )
    
    return fig

# Callback for Statistical test results
@app.callback(
    Output("stat-test-results", "children"),
    [Input("stat-test-algorithms", "value"),
     Input("stat-test-metric", "value"),
     Input("metrics-data", "children")]
)
def update_stat_test_results(selected_algorithms, selected_metric, metrics_json):
    if not metrics_json or not selected_algorithms or len(selected_algorithms) < 2:
        return "Please select at least two algorithms to compare."
    
    metrics_list = json.loads(metrics_json)
    
    # Filter metrics by selected algorithms
    filtered_metrics = [m for m in metrics_list if m["algorithm"] in selected_algorithms]
    
    if len(filtered_metrics) < 2:
        return "Not enough data for selected algorithms."
    
    # Extract metric values
    metric_values = {}
    for metrics in filtered_metrics:
        algorithm = metrics["algorithm"]
        
        if selected_metric == "best_fitness":
            if "solution_quality" in metrics and "best_fitness" in metrics["solution_quality"]:
                metric_values[algorithm] = metrics["solution_quality"]["best_fitness"]
        elif selected_metric == "convergence_rate":
            if "convergence_behavior" in metrics and "convergence_rate" in metrics["convergence_behavior"]:
                metric_values[algorithm] = metrics["convergence_behavior"]["convergence_rate"]
        elif selected_metric == "total_time":
            if "computational_efficiency" in metrics and "total_time" in metrics["computational_efficiency"]:
                metric_values[algorithm] = metrics["computational_efficiency"]["total_time"]
        elif selected_metric == "solution_stability":
            if "robustness_reliability" in metrics and "solution_stability" in metrics["robustness_reliability"]:
                metric_values[algorithm] = metrics["robustness_reliability"]["solution_stability"]
    
    if len(metric_values) < 2:
        return "Not enough data for selected metric."
    
    # Create a simple comparison table
    table_rows = []
    for algorithm, value in metric_values.items():
        table_rows.append(html.Tr([
            html.Td(algorithm),
            html.Td(f"{value:.4f}")
        ]))
    
    # Determine the best algorithm
    if selected_metric in ["best_fitness"]:
        # Lower is better
        best_algorithm = min(metric_values.items(), key=lambda x: x[1])[0]
    else:
        # Higher is better
        best_algorithm = max(metric_values.items(), key=lambda x: x[1])[0]
    
    return html.Div([
        html.H5(f"Comparison of {selected_metric}"),
        html.Table([
            html.Thead(html.Tr([
                html.Th("Algorithm"),
                html.Th("Value")
            ])),
            html.Tbody(table_rows)
        ], className="table table-striped"),
        html.P([
            "Best algorithm: ",
            html.Strong(best_algorithm)
        ])
    ])

# Callback for Distribution analysis plot
@app.callback(
    Output("distribution-analysis-plot", "figure"),
    Input("metrics-data", "children")
)
def update_distribution_analysis_plot(metrics_json):
    if not metrics_json:
        return go.Figure()
    
    metrics_list = json.loads(metrics_json)
    
    # Extract fitness histories for each algorithm
    fitness_data = {}
    for metrics in metrics_list:
        algorithm = metrics["algorithm"]
        if "fitness_history" in metrics:
            fitness_data[algorithm] = metrics["fitness_history"]
    
    if not fitness_data:
        return go.Figure()
    
    fig = go.Figure()
    
    for algorithm, fitness_history in fitness_data.items():
        fig.add_trace(go.Violin(
            y=fitness_history,
            name=algorithm,
            box_visible=True,
            meanline_visible=True
        ))
    
    fig.update_layout(
        title="Fitness Distribution Analysis",
        yaxis_title="Fitness (lower is better)",
        template="plotly_white"
    )
    
    return fig

# Callback for Correlation analysis plot
@app.callback(
    Output("correlation-analysis-plot", "figure"),
    Input("metrics-data", "children")
)
def update_correlation_analysis_plot(metrics_json):
    # For this demo, we'll create a dummy correlation matrix
    variables = ["Best Fitness", "Convergence Rate", "Total Time", "Solution Stability", "Diversity"]
    
    # Create a dummy correlation matrix
    np.random.seed(42)
    corr_matrix = np.random.rand(len(variables), len(variables))
    # Make it symmetric
    corr_matrix = (corr_matrix + corr_matrix.T) / 2
    # Set diagonal to 1
    np.fill_diagonal(corr_matrix, 1)
    
    fig = go.Figure(data=go.Heatmap(
        z=corr_matrix,
        x=variables,
        y=variables,
        colorscale="RdBu_r",
        zmin=-1,
        zmax=1
    ))
    
    fig.update_layout(
        title="Correlation Analysis",
        template="plotly_white"
    )
    
    return fig

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True, host="0.0.0.0", port=8050)
