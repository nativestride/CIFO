import React, { useState, useEffect } from 'react';
import ParameterControls from './components/ParameterControls';
import HillClimbingVisualizer from './components/visualizers/HillClimbingVisualizer';
import SimulatedAnnealingVisualizer from './components/visualizers/SimulatedAnnealingVisualizer';
import GeneticAlgorithmVisualizer from './components/visualizers/GeneticAlgorithmVisualizer';
import IslandGAVisualizer from './components/visualizers/IslandGAVisualizer';

/**
 * Main application component for the Fantasy League Optimization educational website
 */
function App() {
  // State for selected algorithm
  const [selectedAlgorithm, setSelectedAlgorithm] = useState('HillClimbing');
  
  // State for optimization results
  const [optimizationResults, setOptimizationResults] = useState(null);
  
  // State for optimization status
  const [optimizationStatus, setOptimizationStatus] = useState({
    running: false,
    progress: 0,
    message: ''
  });

  // Function to run optimization with selected parameters
  const runOptimization = async (config) => {
    setOptimizationStatus({
      running: true,
      progress: 0,
      message: `Starting ${config.algorithmType} optimization...`
    });

    try {
      // In a real implementation, this would call an API endpoint
      // For now, we'll simulate the optimization process
      for (let i = 1; i <= 10; i++) {
        await new Promise(resolve => setTimeout(resolve, 500));
        setOptimizationStatus({
          running: true,
          progress: i * 10,
          message: `Running ${config.algorithmType} optimization (${i * 10}%)...`
        });
      }

      // Generate mock results based on algorithm type
      const mockResults = generateMockResults(config);
      setOptimizationResults(mockResults);

      setOptimizationStatus({
        running: false,
        progress: 100,
        message: `${config.algorithmType} optimization completed successfully!`
      });
    } catch (error) {
      setOptimizationStatus({
        running: false,
        progress: 0,
        message: `Error: ${error.message}`
      });
    }
  };

  // Function to generate mock optimization results
  const generateMockResults = (config) => {
    const { algorithmType, params, constraints } = config;
    
    // Base fitness history with some randomness
    const iterations = Array.from({ length: 100 }, (_, i) => i);
    const baseHistory = iterations.map(i => 20 - 15 * (1 - Math.exp(-i / 30)) + Math.random() * 2 - 1);
    
    // Common metrics for all algorithms
    const results = {
      algorithm: algorithmType,
      iterations: iterations,
      fitness_history: baseHistory,
      best_fitness: Math.min(...baseHistory),
      best_fitness_iteration: baseHistory.indexOf(Math.min(...baseHistory)),
      final_team: generateMockTeam(constraints),
      execution_time: Math.random() * 2 + 0.5, // 0.5 to 2.5 seconds
      algorithm_specific: {}
    };
    
    // Add algorithm-specific metrics
    switch (algorithmType) {
      case 'HillClimbing':
        results.algorithm_specific = {
          plateau_events: [10, 25, 40, 60].filter(() => Math.random() > 0.3),
          local_optima_escapes: params.randomRestarts > 0 ? [20, 45, 70].slice(0, params.randomRestarts) : [],
          neighborhood_sizes: Array(iterations.length).fill(params.neighborhoodSize),
          improvement_rates: baseHistory.map((v, i, arr) => i > 0 ? arr[i-1] - v : 0)
        };
        break;
        
      case 'SimulatedAnnealing':
        const temperatureHistory = iterations.map(i => params.initialTemperature * Math.pow(params.coolingRate, i));
        results.algorithm_specific = {
          temperature_history: temperatureHistory,
          acceptance_rates: iterations.map(i => 0.9 * (1 - i/iterations.length) + 0.1 * Math.random()),
          acceptance_probabilities: temperatureHistory.map(t => Math.min(1.0, Math.exp(-0.1 / (t > 0 ? t : 0.001)))),
          uphill_moves_accepted: iterations.map(i => Math.random() < 0.3 * (1 - i/iterations.length) ? 1 : 0),
          cooling_schedule_efficiency: Array(iterations.length).fill(params.coolingRate)
        };
        break;
        
      case 'GeneticAlgorithm':
        results.algorithm_specific = {
          population_diversity: iterations.map(i => 0.8 * Math.exp(-i / 50) + 0.2 * Math.random()),
          selection_pressure: Array(iterations.length).fill(params.tournamentSize / 2),
          crossover_success_rates: iterations.map(() => params.crossoverRate * (0.8 + 0.4 * Math.random())),
          mutation_impact: iterations.map(() => params.mutationRate * Math.random()),
          generation_improvement_rates: baseHistory.map((v, i, arr) => i > 0 ? arr[i-1] - v : 0)
        };
        break;
        
      case 'IslandGA':
        const migrationEvents = iterations.filter(i => i > 0 && i % params.migrationInterval === 0);
        results.algorithm_specific = {
          island_diversity: iterations.map(i => 0.7 * Math.exp(-i / 70) + 0.3 * Math.random()),
          inter_island_diversity: iterations.map(i => 0.6 * Math.exp(-i / 60) + 0.4 * Math.random()),
          migration_events: migrationEvents,
          migration_impact: migrationEvents.map(() => 0.5 * Math.random()),
          island_convergence_rates: Array(iterations.length).fill(0).map(() => 0.1 * Math.random())
        };
        break;
        
      default:
        break;
    }
    
    return results;
  };

  // Function to generate a mock team based on constraints
  const generateMockTeam = (constraints) => {
    const positions = ['GK', 'DEF', 'MID', 'FWD'];
    const team = [];
    
    // Generate players for each position based on requirements
    positions.forEach(pos => {
      const count = constraints.positions[pos];
      for (let i = 0; i < count; i++) {
        team.push({
          id: team.length + 1,
          name: `Player ${team.length + 1}`,
          position: pos,
          skill: Math.floor(Math.random() * 20) + 70, // 70-90 skill
          cost: Math.floor(Math.random() * 10) + 5 // 5-15 cost
        });
      }
    });
    
    return team;
  };

  // Render the appropriate visualizer based on selected algorithm
  const renderVisualizer = () => {
    if (!optimizationResults) {
      return (
        <div className="no-results">
          <h3>No optimization results yet</h3>
          <p>Set parameters and run optimization to see results</p>
        </div>
      );
    }

    switch (selectedAlgorithm) {
      case 'HillClimbing':
        return <HillClimbingVisualizer results={optimizationResults} />;
      case 'SimulatedAnnealing':
        return <SimulatedAnnealingVisualizer results={optimizationResults} />;
      case 'GeneticAlgorithm':
        return <GeneticAlgorithmVisualizer results={optimizationResults} />;
      case 'IslandGA':
        return <IslandGAVisualizer results={optimizationResults} />;
      default:
        return null;
    }
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>Fantasy League Optimization</h1>
        <p>Interactive educational tool for optimization algorithms</p>
      </header>

      <main className="app-content">
        <div className="algorithm-selector">
          <h2>Select Algorithm</h2>
          <div className="algorithm-buttons">
            <button 
              className={selectedAlgorithm === 'HillClimbing' ? 'active' : ''}
              onClick={() => setSelectedAlgorithm('HillClimbing')}
            >
              Hill Climbing
            </button>
            <button 
              className={selectedAlgorithm === 'SimulatedAnnealing' ? 'active' : ''}
              onClick={() => setSelectedAlgorithm('SimulatedAnnealing')}
            >
              Simulated Annealing
            </button>
            <button 
              className={selectedAlgorithm === 'GeneticAlgorithm' ? 'active' : ''}
              onClick={() => setSelectedAlgorithm('GeneticAlgorithm')}
            >
              Genetic Algorithm
            </button>
            <button 
              className={selectedAlgorithm === 'IslandGA' ? 'active' : ''}
              onClick={() => setSelectedAlgorithm('IslandGA')}
            >
              Island GA
            </button>
          </div>
        </div>

        <div className="optimization-panel">
          <div className="parameters-section">
            <h2>Optimization Parameters</h2>
            <ParameterControls 
              onRunOptimization={runOptimization} 
              algorithmType={selectedAlgorithm} 
            />
            
            {optimizationStatus.running && (
              <div className="progress-bar">
                <div 
                  className="progress-fill" 
                  style={{ width: `${optimizationStatus.progress}%` }}
                ></div>
              </div>
            )}
            
            <div className="status-message">
              {optimizationStatus.message}
            </div>
          </div>

          <div className="visualization-section">
            <h2>Algorithm Visualization</h2>
            {renderVisualizer()}
          </div>
        </div>

        {optimizationResults && (
          <div className="results-panel">
            <h2>Optimization Results</h2>
            
            <div className="results-summary">
              <div className="result-card">
                <h3>Best Fitness</h3>
                <p className="result-value">{optimizationResults.best_fitness.toFixed(4)}</p>
              </div>
              
              <div className="result-card">
                <h3>Iterations to Best</h3>
                <p className="result-value">{optimizationResults.best_fitness_iteration}</p>
              </div>
              
              <div className="result-card">
                <h3>Execution Time</h3>
                <p className="result-value">{optimizationResults.execution_time.toFixed(2)}s</p>
              </div>
            </div>
            
            <div className="team-results">
              <h3>Optimized Team</h3>
              <table className="team-table">
                <thead>
                  <tr>
                    <th>Player</th>
                    <th>Position</th>
                    <th>Skill</th>
                    <th>Cost</th>
                  </tr>
                </thead>
                <tbody>
                  {optimizationResults.final_team.map(player => (
                    <tr key={player.id}>
                      <td>{player.name}</td>
                      <td>{player.position}</td>
                      <td>{player.skill}</td>
                      <td>{player.cost}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              
              <div className="team-stats">
                <p>
                  <strong>Total Cost:</strong> {optimizationResults.final_team.reduce((sum, p) => sum + p.cost, 0)}
                </p>
                <p>
                  <strong>Average Skill:</strong> {(optimizationResults.final_team.reduce((sum, p) => sum + p.skill, 0) / optimizationResults.final_team.length).toFixed(2)}
                </p>
                <p>
                  <strong>Skill Standard Deviation:</strong> {optimizationResults.best_fitness.toFixed(4)}
                </p>
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="app-footer">
        <p>Fantasy League Optimization Educational Tool - Created for academic research purposes</p>
      </footer>
    </div>
  );
}

export default App;
