import React, { useState } from 'react';

/**
 * Component for controlling optimization parameters for the Fantasy League problem
 */
const ParameterControls = ({ onRunOptimization, algorithmType }) => {
  // Default parameters for each algorithm type
  const defaultParams = {
    HillClimbing: {
      maxIterations: 100,
      randomRestarts: 0,
      neighborhoodSize: 10,
      intensiveSearch: false
    },
    SimulatedAnnealing: {
      maxIterations: 100,
      initialTemperature: 100,
      coolingRate: 0.95,
      minTemperature: 0.01
    },
    GeneticAlgorithm: {
      populationSize: 50,
      generations: 100,
      crossoverRate: 0.8,
      mutationRate: 0.1,
      tournamentSize: 3,
      elitism: true,
      crossoverType: 'onePoint' // onePoint, twoPoint, uniform
    },
    IslandGA: {
      islandCount: 4,
      populationSizePerIsland: 20,
      generations: 100,
      migrationInterval: 10,
      migrationCount: 2,
      migrationTopology: 'ring', // ring, random, broadcast
      crossoverRate: 0.8,
      mutationRate: 0.1
    }
  };

  // Problem constraints
  const [budgetConstraint, setBudgetConstraint] = useState(100);
  const [positionRequirements, setPositionRequirements] = useState({
    GK: 1,
    DEF: 4,
    MID: 4,
    FWD: 2
  });

  // Algorithm parameters
  const [params, setParams] = useState(defaultParams[algorithmType]);

  // Handle parameter changes
  const handleParamChange = (param, value) => {
    setParams({
      ...params,
      [param]: value
    });
  };

  // Handle position requirement changes
  const handlePositionChange = (position, value) => {
    setPositionRequirements({
      ...positionRequirements,
      [position]: parseInt(value)
    });
  };

  // Run optimization with current parameters
  const handleRunClick = () => {
    onRunOptimization({
      algorithmType,
      params,
      constraints: {
        budget: budgetConstraint,
        positions: positionRequirements
      }
    });
  };

  // Reset parameters to defaults
  const handleResetClick = () => {
    setParams(defaultParams[algorithmType]);
    setBudgetConstraint(100);
    setPositionRequirements({
      GK: 1,
      DEF: 4,
      MID: 4,
      FWD: 2
    });
  };

  return (
    <div className="parameter-controls">
      <h3>Problem Constraints</h3>
      <div className="constraint-group">
        <label>
          Budget Constraint:
          <input
            type="number"
            min="50"
            max="200"
            value={budgetConstraint}
            onChange={(e) => setBudgetConstraint(parseInt(e.target.value))}
          />
        </label>
      </div>

      <div className="constraint-group">
        <h4>Position Requirements:</h4>
        <div className="position-controls">
          {Object.entries(positionRequirements).map(([position, count]) => (
            <label key={position}>
              {position}:
              <input
                type="number"
                min="0"
                max="5"
                value={count}
                onChange={(e) => handlePositionChange(position, e.target.value)}
              />
            </label>
          ))}
        </div>
      </div>

      <h3>Algorithm Parameters</h3>
      <div className="algorithm-params">
        {algorithmType === 'HillClimbing' && (
          <>
            <label>
              Max Iterations:
              <input
                type="number"
                min="10"
                max="1000"
                value={params.maxIterations}
                onChange={(e) => handleParamChange('maxIterations', parseInt(e.target.value))}
              />
            </label>
            <label>
              Random Restarts:
              <input
                type="number"
                min="0"
                max="10"
                value={params.randomRestarts}
                onChange={(e) => handleParamChange('randomRestarts', parseInt(e.target.value))}
              />
            </label>
            <label>
              Neighborhood Size:
              <input
                type="number"
                min="1"
                max="20"
                value={params.neighborhoodSize}
                onChange={(e) => handleParamChange('neighborhoodSize', parseInt(e.target.value))}
              />
            </label>
            <label>
              Intensive Search:
              <input
                type="checkbox"
                checked={params.intensiveSearch}
                onChange={(e) => handleParamChange('intensiveSearch', e.target.checked)}
              />
            </label>
          </>
        )}

        {algorithmType === 'SimulatedAnnealing' && (
          <>
            <label>
              Max Iterations:
              <input
                type="number"
                min="10"
                max="1000"
                value={params.maxIterations}
                onChange={(e) => handleParamChange('maxIterations', parseInt(e.target.value))}
              />
            </label>
            <label>
              Initial Temperature:
              <input
                type="number"
                min="10"
                max="1000"
                step="10"
                value={params.initialTemperature}
                onChange={(e) => handleParamChange('initialTemperature', parseFloat(e.target.value))}
              />
            </label>
            <label>
              Cooling Rate:
              <input
                type="number"
                min="0.5"
                max="0.99"
                step="0.01"
                value={params.coolingRate}
                onChange={(e) => handleParamChange('coolingRate', parseFloat(e.target.value))}
              />
            </label>
            <label>
              Min Temperature:
              <input
                type="number"
                min="0.001"
                max="1"
                step="0.001"
                value={params.minTemperature}
                onChange={(e) => handleParamChange('minTemperature', parseFloat(e.target.value))}
              />
            </label>
          </>
        )}

        {algorithmType === 'GeneticAlgorithm' && (
          <>
            <label>
              Population Size:
              <input
                type="number"
                min="10"
                max="200"
                value={params.populationSize}
                onChange={(e) => handleParamChange('populationSize', parseInt(e.target.value))}
              />
            </label>
            <label>
              Generations:
              <input
                type="number"
                min="10"
                max="500"
                value={params.generations}
                onChange={(e) => handleParamChange('generations', parseInt(e.target.value))}
              />
            </label>
            <label>
              Crossover Rate:
              <input
                type="number"
                min="0.1"
                max="1"
                step="0.1"
                value={params.crossoverRate}
                onChange={(e) => handleParamChange('crossoverRate', parseFloat(e.target.value))}
              />
            </label>
            <label>
              Mutation Rate:
              <input
                type="number"
                min="0.01"
                max="0.5"
                step="0.01"
                value={params.mutationRate}
                onChange={(e) => handleParamChange('mutationRate', parseFloat(e.target.value))}
              />
            </label>
            <label>
              Tournament Size:
              <input
                type="number"
                min="2"
                max="10"
                value={params.tournamentSize}
                onChange={(e) => handleParamChange('tournamentSize', parseInt(e.target.value))}
              />
            </label>
            <label>
              Elitism:
              <input
                type="checkbox"
                checked={params.elitism}
                onChange={(e) => handleParamChange('elitism', e.target.checked)}
              />
            </label>
            <label>
              Crossover Type:
              <select
                value={params.crossoverType}
                onChange={(e) => handleParamChange('crossoverType', e.target.value)}
              >
                <option value="onePoint">One Point</option>
                <option value="twoPoint">Two Point</option>
                <option value="uniform">Uniform</option>
              </select>
            </label>
          </>
        )}

        {algorithmType === 'IslandGA' && (
          <>
            <label>
              Island Count:
              <input
                type="number"
                min="2"
                max="10"
                value={params.islandCount}
                onChange={(e) => handleParamChange('islandCount', parseInt(e.target.value))}
              />
            </label>
            <label>
              Population Size Per Island:
              <input
                type="number"
                min="10"
                max="100"
                value={params.populationSizePerIsland}
                onChange={(e) => handleParamChange('populationSizePerIsland', parseInt(e.target.value))}
              />
            </label>
            <label>
              Generations:
              <input
                type="number"
                min="10"
                max="500"
                value={params.generations}
                onChange={(e) => handleParamChange('generations', parseInt(e.target.value))}
              />
            </label>
            <label>
              Migration Interval:
              <input
                type="number"
                min="1"
                max="50"
                value={params.migrationInterval}
                onChange={(e) => handleParamChange('migrationInterval', parseInt(e.target.value))}
              />
            </label>
            <label>
              Migration Count:
              <input
                type="number"
                min="1"
                max="10"
                value={params.migrationCount}
                onChange={(e) => handleParamChange('migrationCount', parseInt(e.target.value))}
              />
            </label>
            <label>
              Migration Topology:
              <select
                value={params.migrationTopology}
                onChange={(e) => handleParamChange('migrationTopology', e.target.value)}
              >
                <option value="ring">Ring</option>
                <option value="random">Random</option>
                <option value="broadcast">Broadcast</option>
              </select>
            </label>
            <label>
              Crossover Rate:
              <input
                type="number"
                min="0.1"
                max="1"
                step="0.1"
                value={params.crossoverRate}
                onChange={(e) => handleParamChange('crossoverRate', parseFloat(e.target.value))}
              />
            </label>
            <label>
              Mutation Rate:
              <input
                type="number"
                min="0.01"
                max="0.5"
                step="0.01"
                value={params.mutationRate}
                onChange={(e) => handleParamChange('mutationRate', parseFloat(e.target.value))}
              />
            </label>
          </>
        )}
      </div>

      <div className="control-buttons">
        <button className="run-button" onClick={handleRunClick}>
          Run Optimization
        </button>
        <button className="reset-button" onClick={handleResetClick}>
          Reset Parameters
        </button>
      </div>
    </div>
  );
};

export default ParameterControls;
